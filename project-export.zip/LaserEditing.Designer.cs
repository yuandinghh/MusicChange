﻿
namespace MusicChange
{
	partial class LaserEditing
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if(disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		//private System.Windows.Forms.KeyEventHandler GetKeyEventHandler( )
		//{
		//	//return new System.Windows.Forms.KeyEventHandler( this.LaserEditing_KeyDown );
		//}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		//private void InitializeComponent(System.Windows.Forms.KeyEventHandler keyEventHandler)
		private void InitializeComponent()

		{
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LaserEditing));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.Ptop = new DevComponents.DotNetBar.PanelEx();
            this.globalsetting = new DevComponents.DotNetBar.ButtonX();
            this.Modifythephoto = new DevComponents.DotNetBar.ButtonX();
            this.topleft = new System.Windows.Forms.Panel();
            this.min = new System.Windows.Forms.Button();
            this.max = new System.Windows.Forms.Button();
            this.quit = new System.Windows.Forms.Button();
            this.logo = new DevComponents.DotNetBar.ButtonX();
            this.cut = new DevComponents.DotNetBar.ButtonX();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.sC3 = new System.Windows.Forms.SplitContainer();
            this.upperleft = new System.Windows.Forms.Panel();
            this.rightChannelProgressBar = new System.Windows.Forms.ProgressBar();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.leftChannelProgressBar = new System.Windows.Forms.ProgressBar();
            this.panel4 = new System.Windows.Forms.Panel();
            this.qrcode1 = new System.Windows.Forms.Button();
            this.openfile = new System.Windows.Forms.Button();
            this.dG = new DevComponents.DotNetBar.Controls.DataGridViewX();
            this.lefttopfile = new System.Windows.Forms.Panel();
            this.qrcode0 = new DevComponents.DotNetBar.ButtonX();
            this.importdata = new DevComponents.DotNetBar.ButtonX();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.inoutmatiral = new DevComponents.DotNetBar.ButtonX();
            this.personalcollection = new DevComponents.DotNetBar.ButtonX();
            this.personaMcollection = new DevComponents.DotNetBar.ButtonX();
            this.hot = new System.Windows.Forms.Button();
            this.leftmaitrial = new DevComponents.DotNetBar.PanelEx();
            this.leftmatrial = new DevComponents.DotNetBar.PanelEx();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.material = new DevComponents.DotNetBar.ButtonX();
            this.audio = new DevComponents.DotNetBar.ButtonX();
            this.sC4 = new System.Windows.Forms.SplitContainer();
            this.videoView1 = new LibVLCSharp.WinForms.VideoView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.progressBar = new System.Windows.Forms.TrackBar();
            this.volumeControlPanel = new System.Windows.Forms.Panel();
            this.buttonX1 = new DevComponents.DotNetBar.ButtonX();
            this.vieweMax = new DevComponents.DotNetBar.ButtonX();
            this.volumenum = new System.Windows.Forms.Label();
            this.volumeTrackBar = new System.Windows.Forms.TrackBar();
            this.playPauseButton = new System.Windows.Forms.Button();
            this.fitToWindowButton = new DevComponents.DotNetBar.ButtonX();
            this.totalTimeLabel = new System.Windows.Forms.Label();
            this.currentTimeLabel = new System.Windows.Forms.Label();
            this.zoomInButton = new DevComponents.DotNetBar.ButtonX();
            this.zoomOutButton = new DevComponents.DotNetBar.ButtonX();
            this.stopButton = new System.Windows.Forms.Button();
            this.muteButton = new DevComponents.DotNetBar.ButtonX();
            this.temp2 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.temp1 = new System.Windows.Forms.TextBox();
            this.temp = new System.Windows.Forms.TextBox();
            this.sC5 = new System.Windows.Forms.SplitContainer();
            this.sC6 = new System.Windows.Forms.SplitContainer();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.progressTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.Ptop.SuspendLayout();
            this.topleft.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sC3)).BeginInit();
            this.sC3.Panel1.SuspendLayout();
            this.sC3.Panel2.SuspendLayout();
            this.sC3.SuspendLayout();
            this.upperleft.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dG)).BeginInit();
            this.lefttopfile.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.leftmatrial.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sC4)).BeginInit();
            this.sC4.Panel1.SuspendLayout();
            this.sC4.Panel2.SuspendLayout();
            this.sC4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.videoView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.progressBar)).BeginInit();
            this.volumeControlPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.volumeTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sC5)).BeginInit();
            this.sC5.Panel2.SuspendLayout();
            this.sC5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sC6)).BeginInit();
            this.sC6.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.MinimumSize = new System.Drawing.Size(0, 40);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.Black;
            this.splitContainer1.Panel1.Controls.Add(this.Ptop);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1842, 1033);
            this.splitContainer1.SplitterDistance = 28;
            this.splitContainer1.TabIndex = 0;
            // 
            // Ptop
            // 
            this.Ptop.CanvasColor = System.Drawing.SystemColors.Control;
            this.Ptop.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.VS2005;
            this.Ptop.Controls.Add(this.globalsetting);
            this.Ptop.Controls.Add(this.Modifythephoto);
            this.Ptop.Controls.Add(this.topleft);
            this.Ptop.Controls.Add(this.logo);
            this.Ptop.Controls.Add(this.cut);
            this.Ptop.DisabledBackColor = System.Drawing.Color.Empty;
            this.Ptop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Ptop.Location = new System.Drawing.Point(0, 0);
            this.Ptop.Name = "Ptop";
            this.Ptop.Size = new System.Drawing.Size(1842, 28);
            this.Ptop.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.Ptop.Style.BackColor1.Color = System.Drawing.Color.Black;
            this.Ptop.Style.BackColor2.Color = System.Drawing.Color.Black;
            this.Ptop.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.Ptop.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.Ptop.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.Ptop.Style.GradientAngle = 90;
            this.Ptop.TabIndex = 3;
            this.Ptop.Text = "panelEx4";
            this.Ptop.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelEx4_MouseDown);
            // 
            // globalsetting
            // 
            this.globalsetting.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.globalsetting.AutoSize = true;
            this.globalsetting.BackColor = System.Drawing.Color.Black;
            this.globalsetting.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.globalsetting.Dock = System.Windows.Forms.DockStyle.Right;
            this.globalsetting.Font = new System.Drawing.Font("楷体", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(120)));
            this.globalsetting.Location = new System.Drawing.Point(1541, 0);
            this.globalsetting.Margin = new System.Windows.Forms.Padding(30);
            this.globalsetting.Name = "globalsetting";
            this.globalsetting.Size = new System.Drawing.Size(130, 28);
            this.globalsetting.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2013;
            this.globalsetting.Symbol = "";
            this.globalsetting.SymbolColor = System.Drawing.Color.Lime;
            this.globalsetting.SymbolSize = 12F;
            this.globalsetting.TabIndex = 1;
            this.globalsetting.Text = "全局设置";
            this.globalsetting.TextColor = System.Drawing.Color.White;
            this.globalsetting.Click += new System.EventHandler(this.buttonx11_Click);
            // 
            // Modifythephoto
            // 
            this.Modifythephoto.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Modifythephoto.BackColor = System.Drawing.Color.Green;
            this.Modifythephoto.ColorTable = DevComponents.DotNetBar.eButtonColor.Office2007WithBackground;
            this.Modifythephoto.Dock = System.Windows.Forms.DockStyle.Left;
            this.Modifythephoto.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(120)));
            this.Modifythephoto.Location = new System.Drawing.Point(136, 0);
            this.Modifythephoto.Name = "Modifythephoto";
            this.Modifythephoto.Size = new System.Drawing.Size(133, 28);
            this.Modifythephoto.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2013;
            this.Modifythephoto.Symbol = "";
            this.Modifythephoto.SymbolColor = System.Drawing.Color.Maroon;
            this.Modifythephoto.SymbolSize = 1F;
            this.Modifythephoto.TabIndex = 0;
            this.Modifythephoto.Text = "处理图片";
            this.Modifythephoto.TextAlignment = DevComponents.DotNetBar.eButtonTextAlignment.Left;
            this.Modifythephoto.TextColor = System.Drawing.Color.Black;
            this.Modifythephoto.Click += new System.EventHandler(this.修改图片_Click);
            // 
            // topleft
            // 
            this.topleft.Controls.Add(this.min);
            this.topleft.Controls.Add(this.max);
            this.topleft.Controls.Add(this.quit);
            this.topleft.Dock = System.Windows.Forms.DockStyle.Right;
            this.topleft.ForeColor = System.Drawing.SystemColors.ControlText;
            this.topleft.Location = new System.Drawing.Point(1671, 0);
            this.topleft.Name = "topleft";
            this.topleft.Size = new System.Drawing.Size(171, 28);
            this.topleft.TabIndex = 2;
            // 
            // min
            // 
            this.min.BackColor = System.Drawing.Color.Black;
            this.min.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.min.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.min.ForeColor = System.Drawing.Color.White;
            this.min.Image = global::MusicChange.Properties.Resources.最小化;
            this.min.Location = new System.Drawing.Point(52, 0);
            this.min.Margin = new System.Windows.Forms.Padding(5);
            this.min.Name = "min";
            this.min.Size = new System.Drawing.Size(30, 30);
            this.min.TabIndex = 27;
            this.min.UseVisualStyleBackColor = false;
            this.min.Click += new System.EventHandler(this.button42_Click);
            // 
            // max
            // 
            this.max.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.max.BackColor = System.Drawing.Color.Black;
            this.max.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.max.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.max.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.max.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.max.Image = global::MusicChange.Properties.Resources.最大化;
            this.max.Location = new System.Drawing.Point(85, 3);
            this.max.Name = "max";
            this.max.Size = new System.Drawing.Size(30, 30);
            this.max.TabIndex = 26;
            this.max.UseVisualStyleBackColor = false;
            this.max.Click += new System.EventHandler(this.button3_Click);
            // 
            // quit
            // 
            this.quit.AutoSize = true;
            this.quit.BackColor = System.Drawing.Color.Black;
            this.quit.Dock = System.Windows.Forms.DockStyle.Right;
            this.quit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.quit.Font = new System.Drawing.Font("宋体", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.quit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.quit.Location = new System.Drawing.Point(117, 0);
            this.quit.Margin = new System.Windows.Forms.Padding(6, 3, 3, 3);
            this.quit.Name = "quit";
            this.quit.Size = new System.Drawing.Size(54, 28);
            this.quit.TabIndex = 25;
            this.quit.Text = "退出";
            this.quit.UseVisualStyleBackColor = false;
            this.quit.Click += new System.EventHandler(this.button8_Click);
            // 
            // logo
            // 
            this.logo.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.logo.AutoSize = true;
            this.logo.BackColor = System.Drawing.Color.Black;
            this.logo.ColorTable = DevComponents.DotNetBar.eButtonColor.Blue;
            this.logo.Dock = System.Windows.Forms.DockStyle.Left;
            this.logo.Font = new System.Drawing.Font("宋体", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(138)));
            this.logo.Location = new System.Drawing.Point(0, 0);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(136, 34);
            this.logo.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2013;
            this.logo.SymbolColor = System.Drawing.Color.White;
            this.logo.TabIndex = 1;
            this.logo.Text = "激光快剪";
            this.logo.TextAlignment = DevComponents.DotNetBar.eButtonTextAlignment.Left;
            this.logo.TextColor = System.Drawing.Color.White;
            // 
            // cut
            // 
            this.cut.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.cut.BackColor = System.Drawing.Color.Green;
            this.cut.ColorTable = DevComponents.DotNetBar.eButtonColor.Office2007WithBackground;
            this.cut.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(120)));
            this.cut.Location = new System.Drawing.Point(321, 3);
            this.cut.Name = "cut";
            this.cut.Size = new System.Drawing.Size(81, 28);
            this.cut.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2013;
            this.cut.Symbol = "";
            this.cut.SymbolColor = System.Drawing.Color.Maroon;
            this.cut.SymbolSize = 1F;
            this.cut.TabIndex = 1;
            this.cut.Text = "Cut";
            this.cut.TextAlignment = DevComponents.DotNetBar.eButtonTextAlignment.Left;
            this.cut.TextColor = System.Drawing.Color.Black;
            this.cut.Click += new System.EventHandler(this.buttonx6_Click);
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.splitContainer2.Panel1.Controls.Add(this.sC3);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.splitContainer2.Panel2.Controls.Add(this.sC5);
            this.splitContainer2.Size = new System.Drawing.Size(1842, 1001);
            this.splitContainer2.SplitterDistance = 680;
            this.splitContainer2.TabIndex = 0;
            // 
            // sC3
            // 
            this.sC3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sC3.Location = new System.Drawing.Point(0, 0);
            this.sC3.Name = "sC3";
            // 
            // sC3.Panel1
            // 
            this.sC3.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.sC3.Panel1.Controls.Add(this.upperleft);
            this.sC3.Panel1.Controls.Add(this.lefttopfile);
            this.sC3.Panel1.Controls.Add(this.flowLayoutPanel2);
            this.sC3.Panel1.Controls.Add(this.leftmaitrial);
            this.sC3.Panel1.Controls.Add(this.leftmatrial);
            this.sC3.Panel1.Margin = new System.Windows.Forms.Padding(5);
            this.sC3.Panel1.Padding = new System.Windows.Forms.Padding(2);
            this.sC3.Panel1MinSize = 200;
            // 
            // sC3.Panel2
            // 
            this.sC3.Panel2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sC3.Panel2.Controls.Add(this.sC4);
            this.sC3.Panel2MinSize = 800;
            this.sC3.Size = new System.Drawing.Size(1842, 680);
            this.sC3.SplitterDistance = 680;
            this.sC3.TabIndex = 0;
            this.sC3.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.sC3_SplitterMoved);
            // 
            // upperleft
            // 
            this.upperleft.BackColor = System.Drawing.Color.DimGray;
            this.upperleft.Controls.Add(this.rightChannelProgressBar);
            this.upperleft.Controls.Add(this.dataGridView1);
            this.upperleft.Controls.Add(this.leftChannelProgressBar);
            this.upperleft.Controls.Add(this.panel4);
            this.upperleft.Dock = System.Windows.Forms.DockStyle.Fill;
            this.upperleft.Location = new System.Drawing.Point(82, 97);
            this.upperleft.Name = "upperleft";
            this.upperleft.Size = new System.Drawing.Size(596, 581);
            this.upperleft.TabIndex = 18;
            // 
            // rightChannelProgressBar
            // 
            this.rightChannelProgressBar.Location = new System.Drawing.Point(272, 228);
            this.rightChannelProgressBar.Name = "rightChannelProgressBar";
            this.rightChannelProgressBar.Size = new System.Drawing.Size(177, 23);
            this.rightChannelProgressBar.TabIndex = 2;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Location = new System.Drawing.Point(6, 289);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 27;
            this.dataGridView1.Size = new System.Drawing.Size(587, 171);
            this.dataGridView1.TabIndex = 2;
            // 
            // leftChannelProgressBar
            // 
            this.leftChannelProgressBar.Location = new System.Drawing.Point(272, 199);
            this.leftChannelProgressBar.Name = "leftChannelProgressBar";
            this.leftChannelProgressBar.Size = new System.Drawing.Size(177, 23);
            this.leftChannelProgressBar.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DimGray;
            this.panel4.Controls.Add(this.qrcode1);
            this.panel4.Controls.Add(this.openfile);
            this.panel4.Controls.Add(this.dG);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(5);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(596, 90);
            this.panel4.TabIndex = 0;
            this.panel4.SizeChanged += new System.EventHandler(this.panel4_SizeChanged);
            // 
            // qrcode1
            // 
            this.qrcode1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.qrcode1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qrcode1.Image = global::MusicChange.Properties.Resources.QRcode;
            this.qrcode1.Location = new System.Drawing.Point(335, 0);
            this.qrcode1.Margin = new System.Windows.Forms.Padding(0);
            this.qrcode1.Name = "qrcode1";
            this.qrcode1.Size = new System.Drawing.Size(70, 80);
            this.qrcode1.TabIndex = 2;
            this.qrcode1.UseVisualStyleBackColor = true;
            this.qrcode1.Click += new System.EventHandler(this.buttonX12_Click);
            // 
            // openfile
            // 
            this.openfile.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.openfile.BackColor = System.Drawing.Color.DimGray;
            this.openfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.openfile.Font = new System.Drawing.Font("楷体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.openfile.ForeColor = System.Drawing.Color.White;
            this.openfile.Image = global::MusicChange.Properties.Resources.loading;
            this.openfile.Location = new System.Drawing.Point(22, 3);
            this.openfile.Margin = new System.Windows.Forms.Padding(0, 3, 3, 3);
            this.openfile.Name = "openfile";
            this.openfile.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.openfile.Size = new System.Drawing.Size(246, 80);
            this.openfile.TabIndex = 1;
            this.openfile.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.openfile.UseVisualStyleBackColor = false;
            this.openfile.Click += new System.EventHandler(this.button2_Click);
            // 
            // dG
            // 
            this.dG.BackgroundColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dG.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dG.DefaultCellStyle = dataGridViewCellStyle5;
            this.dG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dG.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dG.Location = new System.Drawing.Point(0, 0);
            this.dG.Name = "dG";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dG.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dG.RowHeadersWidth = 51;
            this.dG.RowTemplate.Height = 27;
            this.dG.Size = new System.Drawing.Size(596, 90);
            this.dG.TabIndex = 1;
            // 
            // lefttopfile
            // 
            this.lefttopfile.BackColor = System.Drawing.Color.Black;
            this.lefttopfile.Controls.Add(this.qrcode0);
            this.lefttopfile.Controls.Add(this.importdata);
            this.lefttopfile.Dock = System.Windows.Forms.DockStyle.Top;
            this.lefttopfile.Location = new System.Drawing.Point(82, 62);
            this.lefttopfile.Margin = new System.Windows.Forms.Padding(6);
            this.lefttopfile.Name = "lefttopfile";
            this.lefttopfile.Size = new System.Drawing.Size(596, 35);
            this.lefttopfile.TabIndex = 11;
            this.lefttopfile.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // qrcode0
            // 
            this.qrcode0.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.qrcode0.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.qrcode0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.qrcode0.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.qrcode0.Font = new System.Drawing.Font("宋体", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(120)));
            this.qrcode0.Location = new System.Drawing.Point(95, 5);
            this.qrcode0.Name = "qrcode0";
            this.qrcode0.Size = new System.Drawing.Size(30, 26);
            this.qrcode0.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2013;
            this.qrcode0.Symbol = "";
            this.qrcode0.SymbolColor = System.Drawing.Color.White;
            this.qrcode0.SymbolSize = 14F;
            this.qrcode0.TabIndex = 2;
            this.qrcode0.TextAlignment = DevComponents.DotNetBar.eButtonTextAlignment.Left;
            this.qrcode0.TextColor = System.Drawing.Color.Transparent;
            // 
            // importdata
            // 
            this.importdata.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.importdata.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.importdata.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.importdata.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.importdata.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(120)));
            this.importdata.Location = new System.Drawing.Point(5, 4);
            this.importdata.Name = "importdata";
            this.importdata.Size = new System.Drawing.Size(75, 26);
            this.importdata.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.importdata.Symbol = "";
            this.importdata.SymbolColor = System.Drawing.Color.Lime;
            this.importdata.SymbolSize = 12F;
            this.importdata.TabIndex = 2;
            this.importdata.Text = "导入";
            this.importdata.TextAlignment = DevComponents.DotNetBar.eButtonTextAlignment.Left;
            this.importdata.TextColor = System.Drawing.Color.White;
            this.importdata.ThemeAware = true;
            this.importdata.Click += new System.EventHandler(this.buttonx7_Click);
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.BackColor = System.Drawing.Color.Black;
            this.flowLayoutPanel2.Controls.Add(this.inoutmatiral);
            this.flowLayoutPanel2.Controls.Add(this.personalcollection);
            this.flowLayoutPanel2.Controls.Add(this.personaMcollection);
            this.flowLayoutPanel2.Controls.Add(this.hot);
            this.flowLayoutPanel2.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(2, 62);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(5);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Padding = new System.Windows.Forms.Padding(3);
            this.flowLayoutPanel2.Size = new System.Drawing.Size(80, 529);
            this.flowLayoutPanel2.TabIndex = 0;
            this.flowLayoutPanel2.WrapContents = false;
            this.flowLayoutPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel2_Paint);
            // 
            // inoutmatiral
            // 
            this.inoutmatiral.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.inoutmatiral.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.inoutmatiral.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.inoutmatiral.BackColor = System.Drawing.Color.GreenYellow;
            this.inoutmatiral.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.inoutmatiral.Font = new System.Drawing.Font("宋体", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(120)));
            this.inoutmatiral.Location = new System.Drawing.Point(8, 18);
            this.inoutmatiral.Margin = new System.Windows.Forms.Padding(5, 15, 5, 5);
            this.inoutmatiral.Name = "inoutmatiral";
            this.inoutmatiral.Size = new System.Drawing.Size(70, 26);
            this.inoutmatiral.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.inoutmatiral.SymbolColor = System.Drawing.Color.Black;
            this.inoutmatiral.SymbolSet = DevComponents.DotNetBar.eSymbolSet.Material;
            this.inoutmatiral.SymbolSize = 1F;
            this.inoutmatiral.TabIndex = 15;
            this.inoutmatiral.Text = "导入素材";
            this.inoutmatiral.TextAlignment = DevComponents.DotNetBar.eButtonTextAlignment.Left;
            this.inoutmatiral.TextColor = System.Drawing.Color.Black;
            this.inoutmatiral.UseMnemonic = false;
            this.inoutmatiral.Click += new System.EventHandler(this.buttonx8_Click);
            // 
            // personalcollection
            // 
            this.personalcollection.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.personalcollection.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.personalcollection.BackColor = System.Drawing.Color.GreenYellow;
            this.personalcollection.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.personalcollection.Font = new System.Drawing.Font("宋体", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(120)));
            this.personalcollection.Location = new System.Drawing.Point(8, 54);
            this.personalcollection.Margin = new System.Windows.Forms.Padding(5);
            this.personalcollection.Name = "personalcollection";
            this.personalcollection.Padding = new System.Windows.Forms.Padding(5);
            this.personalcollection.Size = new System.Drawing.Size(70, 26);
            this.personalcollection.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.personalcollection.Symbol = "";
            this.personalcollection.SymbolColor = System.Drawing.Color.Black;
            this.personalcollection.SymbolSize = 1F;
            this.personalcollection.TabIndex = 16;
            this.personalcollection.Text = "个人收藏";
            this.personalcollection.TextAlignment = DevComponents.DotNetBar.eButtonTextAlignment.Left;
            this.personalcollection.TextColor = System.Drawing.Color.Black;
            this.personalcollection.Click += new System.EventHandler(this.buttonx4_Click);
            // 
            // personaMcollection
            // 
            this.personaMcollection.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.personaMcollection.BackColor = System.Drawing.Color.GreenYellow;
            this.personaMcollection.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.personaMcollection.Font = new System.Drawing.Font("宋体", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(120)));
            this.personaMcollection.Location = new System.Drawing.Point(8, 90);
            this.personaMcollection.Margin = new System.Windows.Forms.Padding(5);
            this.personaMcollection.Name = "personaMcollection";
            this.personaMcollection.Padding = new System.Windows.Forms.Padding(5);
            this.personaMcollection.Size = new System.Drawing.Size(70, 26);
            this.personaMcollection.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.personaMcollection.SymbolColor = System.Drawing.Color.Black;
            this.personaMcollection.SymbolSet = DevComponents.DotNetBar.eSymbolSet.Material;
            this.personaMcollection.SymbolSize = 1F;
            this.personaMcollection.TabIndex = 16;
            this.personaMcollection.Text = "官方素材";
            this.personaMcollection.TextAlignment = DevComponents.DotNetBar.eButtonTextAlignment.Left;
            this.personaMcollection.TextColor = System.Drawing.Color.Black;
            this.personaMcollection.Click += new System.EventHandler(this.buttonx5_Click);
            // 
            // hot
            // 
            this.hot.AutoSize = true;
            this.hot.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.hot.FlatAppearance.BorderSize = 0;
            this.hot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.hot.Font = new System.Drawing.Font("楷体", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.hot.ForeColor = System.Drawing.Color.White;
            this.hot.Location = new System.Drawing.Point(8, 131);
            this.hot.Margin = new System.Windows.Forms.Padding(5, 10, 5, 5);
            this.hot.Name = "hot";
            this.hot.Size = new System.Drawing.Size(70, 27);
            this.hot.TabIndex = 17;
            this.hot.Text = "热门";
            this.hot.UseVisualStyleBackColor = true;
            this.hot.Click += new System.EventHandler(this.button1_Click);
            // 
            // leftmaitrial
            // 
            this.leftmaitrial.CanvasColor = System.Drawing.SystemColors.ButtonHighlight;
            this.leftmaitrial.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.leftmaitrial.DisabledBackColor = System.Drawing.Color.Empty;
            this.leftmaitrial.Dock = System.Windows.Forms.DockStyle.Left;
            this.leftmaitrial.Location = new System.Drawing.Point(2, 62);
            this.leftmaitrial.Name = "leftmaitrial";
            this.leftmaitrial.Size = new System.Drawing.Size(80, 616);
            this.leftmaitrial.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.leftmaitrial.Style.BackColor1.Color = System.Drawing.Color.Black;
            this.leftmaitrial.Style.BackColor2.Color = System.Drawing.Color.Black;
            this.leftmaitrial.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.leftmaitrial.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.leftmaitrial.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.leftmaitrial.Style.GradientAngle = 90;
            this.leftmaitrial.TabIndex = 4;
            this.leftmaitrial.Text = "panelEx3";
            // 
            // leftmatrial
            // 
            this.leftmatrial.CanvasColor = System.Drawing.SystemColors.Control;
            this.leftmatrial.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.leftmatrial.Controls.Add(this.flowLayoutPanel1);
            this.leftmatrial.DisabledBackColor = System.Drawing.Color.Empty;
            this.leftmatrial.Dock = System.Windows.Forms.DockStyle.Top;
            this.leftmatrial.Location = new System.Drawing.Point(2, 2);
            this.leftmatrial.Name = "leftmatrial";
            this.leftmatrial.Size = new System.Drawing.Size(676, 60);
            this.leftmatrial.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.leftmatrial.Style.BackColor1.Color = System.Drawing.Color.Black;
            this.leftmatrial.Style.BackColor2.Color = System.Drawing.Color.Black;
            this.leftmatrial.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.leftmatrial.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.leftmatrial.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.leftmatrial.Style.GradientAngle = 90;
            this.leftmatrial.TabIndex = 0;
            this.leftmatrial.Text = "panelEx2";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.Black;
            this.flowLayoutPanel1.Controls.Add(this.material);
            this.flowLayoutPanel1.Controls.Add(this.audio);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(676, 60);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // material
            // 
            this.material.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.material.BackColor = System.Drawing.Color.Black;
            this.material.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.material.Font = new System.Drawing.Font("楷体", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.material.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.material.Location = new System.Drawing.Point(3, 3);
            this.material.Name = "material";
            this.material.Size = new System.Drawing.Size(58, 58);
            this.material.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.material.SubItemsExpandWidth = 15;
            this.material.Symbol = "";
            this.material.SymbolColor = System.Drawing.Color.GreenYellow;
            this.material.SymbolSize = 12F;
            this.material.TabIndex = 4;
            this.material.Text = "素材";
            this.material.TextColor = System.Drawing.Color.White;
            this.material.ThemeAware = true;
            this.material.Click += new System.EventHandler(this.buttonX3_Click);
            // 
            // audio
            // 
            this.audio.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.audio.BackColor = System.Drawing.Color.Black;
            this.audio.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.audio.Font = new System.Drawing.Font("楷体", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.audio.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.audio.Location = new System.Drawing.Point(67, 3);
            this.audio.Name = "audio";
            this.audio.Size = new System.Drawing.Size(58, 58);
            this.audio.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.audio.SubItemsExpandWidth = 15;
            this.audio.Symbol = "";
            this.audio.SymbolColor = System.Drawing.Color.DodgerBlue;
            this.audio.SymbolSize = 12F;
            this.audio.TabIndex = 0;
            this.audio.Text = "音频";
            this.audio.TextColor = System.Drawing.Color.White;
            this.audio.ThemeAware = true;
            this.audio.Click += new System.EventHandler(this.buttonX2_Click);
            // 
            // sC4
            // 
            this.sC4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sC4.Location = new System.Drawing.Point(0, 0);
            this.sC4.Name = "sC4";
            // 
            // sC4.Panel1
            // 
            this.sC4.Panel1.AutoScroll = true;
            this.sC4.Panel1.AutoScrollMinSize = new System.Drawing.Size(630, 0);
            this.sC4.Panel1.Controls.Add(this.videoView1);
            this.sC4.Panel1.Controls.Add(this.panel1);
            this.sC4.Panel1.Controls.Add(this.progressBar);
            this.sC4.Panel1.Controls.Add(this.volumeControlPanel);
            this.sC4.Panel1MinSize = 630;
            // 
            // sC4.Panel2
            // 
            this.sC4.Panel2.BackColor = System.Drawing.Color.DimGray;
            this.sC4.Panel2.Controls.Add(this.temp2);
            this.sC4.Panel2.Controls.Add(this.button4);
            this.sC4.Panel2.Controls.Add(this.temp1);
            this.sC4.Panel2.Controls.Add(this.temp);
            this.sC4.Panel2.Margin = new System.Windows.Forms.Padding(5);
            this.sC4.Panel2MinSize = 300;
            this.sC4.Size = new System.Drawing.Size(1158, 680);
            this.sC4.SplitterDistance = 650;
            this.sC4.TabIndex = 0;
            this.sC4.SplitterMoving += new System.Windows.Forms.SplitterCancelEventHandler(this.sC4_SplitterMoving);
            this.sC4.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.sC4_SplitterMoved);
            // 
            // videoView1
            // 
            this.videoView1.BackColor = System.Drawing.Color.LimeGreen;
            this.videoView1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.videoView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.videoView1.Location = new System.Drawing.Point(0, 30);
            this.videoView1.Margin = new System.Windows.Forms.Padding(10);
            this.videoView1.MediaPlayer = null;
            this.videoView1.Name = "videoView1";
            this.videoView1.Padding = new System.Windows.Forms.Padding(5);
            this.videoView1.Size = new System.Drawing.Size(650, 594);
            this.videoView1.TabIndex = 5;
            this.videoView1.Resize += new System.EventHandler(this.videoView1_Resize);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(650, 30);
            this.panel1.TabIndex = 4;
            // 
            // progressBar
            // 
            this.progressBar.AutoSize = false;
            this.progressBar.BackColor = System.Drawing.Color.Gray;
            this.progressBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.progressBar.Location = new System.Drawing.Point(0, 624);
            this.progressBar.Margin = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.progressBar.Maximum = 1000;
            this.progressBar.Name = "progressBar";
            this.progressBar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.progressBar.Size = new System.Drawing.Size(650, 26);
            this.progressBar.TabIndex = 2;
            this.progressBar.TickStyle = System.Windows.Forms.TickStyle.None;
            this.progressBar.Scroll += new System.EventHandler(this.progressBar_Scroll);
            this.progressBar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.progressBar_MouseDown);
            this.progressBar.MouseUp += new System.Windows.Forms.MouseEventHandler(this.progressBar_MouseUp);
            // 
            // volumeControlPanel
            // 
            this.volumeControlPanel.BackColor = System.Drawing.Color.Black;
            this.volumeControlPanel.Controls.Add(this.buttonX1);
            this.volumeControlPanel.Controls.Add(this.vieweMax);
            this.volumeControlPanel.Controls.Add(this.volumenum);
            this.volumeControlPanel.Controls.Add(this.volumeTrackBar);
            this.volumeControlPanel.Controls.Add(this.playPauseButton);
            this.volumeControlPanel.Controls.Add(this.fitToWindowButton);
            this.volumeControlPanel.Controls.Add(this.totalTimeLabel);
            this.volumeControlPanel.Controls.Add(this.currentTimeLabel);
            this.volumeControlPanel.Controls.Add(this.zoomInButton);
            this.volumeControlPanel.Controls.Add(this.zoomOutButton);
            this.volumeControlPanel.Controls.Add(this.stopButton);
            this.volumeControlPanel.Controls.Add(this.muteButton);
            this.volumeControlPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.volumeControlPanel.ForeColor = System.Drawing.Color.White;
            this.volumeControlPanel.Location = new System.Drawing.Point(0, 650);
            this.volumeControlPanel.MaximumSize = new System.Drawing.Size(0, 30);
            this.volumeControlPanel.MinimumSize = new System.Drawing.Size(0, 30);
            this.volumeControlPanel.Name = "volumeControlPanel";
            this.volumeControlPanel.Padding = new System.Windows.Forms.Padding(2);
            this.volumeControlPanel.Size = new System.Drawing.Size(650, 30);
            this.volumeControlPanel.TabIndex = 1;
            // 
            // buttonX1
            // 
            this.buttonX1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonX1.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonX1.Location = new System.Drawing.Point(539, 6);
            this.buttonX1.Margin = new System.Windows.Forms.Padding(2);
            this.buttonX1.Name = "buttonX1";
            this.buttonX1.Size = new System.Drawing.Size(26, 26);
            this.buttonX1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.buttonX1.Symbol = "57539";
            this.buttonX1.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonX1.SymbolSet = DevComponents.DotNetBar.eSymbolSet.Material;
            this.buttonX1.SymbolSize = 14F;
            this.buttonX1.TabIndex = 3;
            // 
            // vieweMax
            // 
            this.vieweMax.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.vieweMax.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.vieweMax.Dock = System.Windows.Forms.DockStyle.Right;
            this.vieweMax.Location = new System.Drawing.Point(622, 2);
            this.vieweMax.Margin = new System.Windows.Forms.Padding(10, 4, 2, 2);
            this.vieweMax.Name = "vieweMax";
            this.vieweMax.Size = new System.Drawing.Size(26, 26);
            this.vieweMax.Style = DevComponents.DotNetBar.eDotNetBarStyle.Windows7;
            this.vieweMax.Symbol = "";
            this.vieweMax.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.vieweMax.SymbolSize = 14F;
            this.vieweMax.TabIndex = 5;
            this.vieweMax.Click += new System.EventHandler(this.vieweMax_Click);
            // 
            // volumenum
            // 
            this.volumenum.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.volumenum.BackColor = System.Drawing.Color.Black;
            this.volumenum.Font = new System.Drawing.Font("宋体", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.volumenum.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.volumenum.Location = new System.Drawing.Point(302, 10);
            this.volumenum.Margin = new System.Windows.Forms.Padding(4);
            this.volumenum.Name = "volumenum";
            this.volumenum.Size = new System.Drawing.Size(40, 24);
            this.volumenum.TabIndex = 4;
            this.volumenum.Text = "80";
            // 
            // volumeTrackBar
            // 
            this.volumeTrackBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.volumeTrackBar.Location = new System.Drawing.Point(206, 6);
            this.volumeTrackBar.Margin = new System.Windows.Forms.Padding(4);
            this.volumeTrackBar.Maximum = 100;
            this.volumeTrackBar.Minimum = 1;
            this.volumeTrackBar.Name = "volumeTrackBar";
            this.volumeTrackBar.Size = new System.Drawing.Size(100, 56);
            this.volumeTrackBar.TabIndex = 4;
            this.volumeTrackBar.TickStyle = System.Windows.Forms.TickStyle.None;
            this.volumeTrackBar.Value = 80;
            this.volumeTrackBar.Scroll += new System.EventHandler(this.VolumeTrackBar_Scroll);
            // 
            // playPauseButton
            // 
            this.playPauseButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.playPauseButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.playPauseButton.Font = new System.Drawing.Font("宋体", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.playPauseButton.ForeColor = System.Drawing.Color.Black;
            this.playPauseButton.Image = global::MusicChange.Properties.Resources.start;
            this.playPauseButton.Location = new System.Drawing.Point(345, 2);
            this.playPauseButton.Margin = new System.Windows.Forms.Padding(4);
            this.playPauseButton.Name = "playPauseButton";
            this.playPauseButton.Size = new System.Drawing.Size(30, 30);
            this.playPauseButton.TabIndex = 4;
            this.playPauseButton.UseVisualStyleBackColor = true;
            this.playPauseButton.Click += new System.EventHandler(this.playPauseButton_Click);
            // 
            // fitToWindowButton
            // 
            this.fitToWindowButton.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.fitToWindowButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.fitToWindowButton.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.fitToWindowButton.Location = new System.Drawing.Point(426, 4);
            this.fitToWindowButton.Margin = new System.Windows.Forms.Padding(2);
            this.fitToWindowButton.Name = "fitToWindowButton";
            this.fitToWindowButton.Padding = new System.Windows.Forms.Padding(5, 2, 2, 2);
            this.fitToWindowButton.Size = new System.Drawing.Size(26, 26);
            this.fitToWindowButton.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2013;
            this.fitToWindowButton.Symbol = "";
            this.fitToWindowButton.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.fitToWindowButton.SymbolSize = 15F;
            this.fitToWindowButton.TabIndex = 7;
            this.fitToWindowButton.Click += new System.EventHandler(this.FitToWindowButton_Click);
            // 
            // totalTimeLabel
            // 
            this.totalTimeLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.totalTimeLabel.Font = new System.Drawing.Font("宋体", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.totalTimeLabel.Location = new System.Drawing.Point(90, 8);
            this.totalTimeLabel.Margin = new System.Windows.Forms.Padding(4);
            this.totalTimeLabel.Name = "totalTimeLabel";
            this.totalTimeLabel.Size = new System.Drawing.Size(80, 17);
            this.totalTimeLabel.TabIndex = 1;
            this.totalTimeLabel.Text = "00:00:00";
            // 
            // currentTimeLabel
            // 
            this.currentTimeLabel.Dock = System.Windows.Forms.DockStyle.Left;
            this.currentTimeLabel.Font = new System.Drawing.Font("宋体", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.currentTimeLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.currentTimeLabel.Location = new System.Drawing.Point(2, 2);
            this.currentTimeLabel.Margin = new System.Windows.Forms.Padding(4);
            this.currentTimeLabel.Name = "currentTimeLabel";
            this.currentTimeLabel.Size = new System.Drawing.Size(80, 26);
            this.currentTimeLabel.TabIndex = 0;
            this.currentTimeLabel.Text = "00:00:00";
            this.currentTimeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zoomInButton
            // 
            this.zoomInButton.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.zoomInButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.zoomInButton.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.zoomInButton.Location = new System.Drawing.Point(498, 4);
            this.zoomInButton.Margin = new System.Windows.Forms.Padding(2);
            this.zoomInButton.Name = "zoomInButton";
            this.zoomInButton.Size = new System.Drawing.Size(26, 26);
            this.zoomInButton.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.zoomInButton.Symbol = "57539";
            this.zoomInButton.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.zoomInButton.SymbolSet = DevComponents.DotNetBar.eSymbolSet.Material;
            this.zoomInButton.SymbolSize = 14F;
            this.zoomInButton.TabIndex = 0;
            this.zoomInButton.Click += new System.EventHandler(this.ZoomInButton_Click);
            // 
            // zoomOutButton
            // 
            this.zoomOutButton.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.zoomOutButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.zoomOutButton.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.zoomOutButton.Location = new System.Drawing.Point(462, 4);
            this.zoomOutButton.Margin = new System.Windows.Forms.Padding(4);
            this.zoomOutButton.Name = "zoomOutButton";
            this.zoomOutButton.Size = new System.Drawing.Size(26, 26);
            this.zoomOutButton.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.zoomOutButton.Symbol = "58838";
            this.zoomOutButton.SymbolColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.zoomOutButton.SymbolSet = DevComponents.DotNetBar.eSymbolSet.Material;
            this.zoomOutButton.SymbolSize = 14F;
            this.zoomOutButton.TabIndex = 6;
            this.zoomOutButton.Click += new System.EventHandler(this.ZoomOutButton_Click);
            // 
            // stopButton
            // 
            this.stopButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.stopButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.stopButton.Font = new System.Drawing.Font("宋体", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.stopButton.ForeColor = System.Drawing.Color.Black;
            this.stopButton.Image = global::MusicChange.Properties.Resources.stop;
            this.stopButton.Location = new System.Drawing.Point(390, 4);
            this.stopButton.Margin = new System.Windows.Forms.Padding(4);
            this.stopButton.Name = "stopButton";
            this.stopButton.Size = new System.Drawing.Size(26, 26);
            this.stopButton.TabIndex = 5;
            this.stopButton.UseVisualStyleBackColor = true;
            this.stopButton.Click += new System.EventHandler(this.StopButton_Click);
            // 
            // muteButton
            // 
            this.muteButton.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.muteButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.muteButton.ColorTable = DevComponents.DotNetBar.eButtonColor.Flat;
            this.muteButton.Location = new System.Drawing.Point(180, 4);
            this.muteButton.Margin = new System.Windows.Forms.Padding(4);
            this.muteButton.Name = "muteButton";
            this.muteButton.Size = new System.Drawing.Size(26, 26);
            this.muteButton.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.muteButton.Symbol = "";
            this.muteButton.SymbolColor = System.Drawing.Color.Salmon;
            this.muteButton.SymbolSize = 14F;
            this.muteButton.TabIndex = 3;
            this.muteButton.Click += new System.EventHandler(this.MuteButton_Click);
            // 
            // temp2
            // 
            this.temp2.Location = new System.Drawing.Point(34, 127);
            this.temp2.Name = "temp2";
            this.temp2.Size = new System.Drawing.Size(261, 25);
            this.temp2.TabIndex = 2;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(57, 281);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(84, 23);
            this.button4.TabIndex = 1;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // temp1
            // 
            this.temp1.Location = new System.Drawing.Point(34, 72);
            this.temp1.Name = "temp1";
            this.temp1.Size = new System.Drawing.Size(261, 25);
            this.temp1.TabIndex = 1;
            // 
            // temp
            // 
            this.temp.Location = new System.Drawing.Point(34, 20);
            this.temp.Name = "temp";
            this.temp.Size = new System.Drawing.Size(261, 25);
            this.temp.TabIndex = 0;
            // 
            // sC5
            // 
            this.sC5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.sC5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sC5.IsSplitterFixed = true;
            this.sC5.Location = new System.Drawing.Point(0, 0);
            this.sC5.Name = "sC5";
            this.sC5.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // sC5.Panel1
            // 
            this.sC5.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            // 
            // sC5.Panel2
            // 
            this.sC5.Panel2.Controls.Add(this.sC6);
            this.sC5.Size = new System.Drawing.Size(1842, 317);
            this.sC5.SplitterDistance = 28;
            this.sC5.TabIndex = 0;
            // 
            // sC6
            // 
            this.sC6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sC6.Location = new System.Drawing.Point(0, 0);
            this.sC6.Margin = new System.Windows.Forms.Padding(5);
            this.sC6.Name = "sC6";
            // 
            // sC6.Panel1
            // 
            this.sC6.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.sC6.Size = new System.Drawing.Size(1842, 285);
            this.sC6.SplitterDistance = 460;
            this.sC6.TabIndex = 0;
            this.sC6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.splitContainer6_MouseMove);
            // 
            // progressTimer
            // 
            this.progressTimer.Tick += new System.EventHandler(this.ProgressTimer_Tick);
            // 
            // LaserEditing
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1842, 1033);
            this.Controls.Add(this.splitContainer1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Location = new System.Drawing.Point(-1920, 358);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MinimumSize = new System.Drawing.Size(1800, 0);
            this.Name = "LaserEditing";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.LaserEditing_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.LaserEditing_KeyDown);
            this.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.LaserEditing_MouseDoubleClick);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.LaserEditing_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.LaserEditing_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.LaserEditing_MouseUp);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.Ptop.ResumeLayout(false);
            this.Ptop.PerformLayout();
            this.topleft.ResumeLayout(false);
            this.topleft.PerformLayout();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.sC3.Panel1.ResumeLayout(false);
            this.sC3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sC3)).EndInit();
            this.sC3.ResumeLayout(false);
            this.upperleft.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dG)).EndInit();
            this.lefttopfile.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel2.PerformLayout();
            this.leftmatrial.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.sC4.Panel1.ResumeLayout(false);
            this.sC4.Panel2.ResumeLayout(false);
            this.sC4.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sC4)).EndInit();
            this.sC4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.videoView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.progressBar)).EndInit();
            this.volumeControlPanel.ResumeLayout(false);
            this.volumeControlPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.volumeTrackBar)).EndInit();
            this.sC5.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sC5)).EndInit();
            this.sC5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sC6)).EndInit();
            this.sC6.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		#endregion 

		#region   ----------  all prvate control 		-------------
		private System.Windows.Forms.SplitContainer splitContainer1;
		private System.Windows.Forms.SplitContainer splitContainer2;
		private System.Windows.Forms.SplitContainer sC3;
		private System.Windows.Forms.SplitContainer sC4;
		private System.Windows.Forms.SplitContainer sC5;
		private System.Windows.Forms.SplitContainer sC6;
		private DevComponents.DotNetBar.ButtonX Modifythephoto;
		private DevComponents.DotNetBar.ButtonX logo;
		private DevComponents.DotNetBar.PanelEx leftmatrial;
		private DevComponents.DotNetBar.ButtonX audio;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
		private DevComponents.DotNetBar.ButtonX material;
		private DevComponents.DotNetBar.PanelEx leftmaitrial;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
		private DevComponents.DotNetBar.ButtonX inoutmatiral;
		private DevComponents.DotNetBar.ButtonX personalcollection;
		private DevComponents.DotNetBar.ButtonX personaMcollection;
		private System.Windows.Forms.Button min;
		private System.Windows.Forms.Button max;
		private System.Windows.Forms.Button quit;
		private System.Windows.Forms.Panel topleft;
		private DevComponents.DotNetBar.ButtonX cut;
		private System.Windows.Forms.Button hot;
		private DevComponents.DotNetBar.PanelEx Ptop;
		private System.Windows.Forms.Panel lefttopfile;
		private DevComponents.DotNetBar.ButtonX qrcode0;
		private DevComponents.DotNetBar.ButtonX importdata;
		private System.Windows.Forms.Panel upperleft;
		private System.Windows.Forms.Panel panel4;
		private DevComponents.DotNetBar.ButtonX globalsetting;
		private System.Windows.Forms.FontDialog fontDialog1;
		private System.Windows.Forms.TextBox temp;
		private System.Windows.Forms.TextBox temp1;
		private System.Windows.Forms.Button openfile;
		private System.Windows.Forms.Button qrcode1;
		private DevComponents.DotNetBar.Controls.DataGridViewX dG;
		private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.Timer progressTimer;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.TrackBar progressBar;
		private System.Windows.Forms.Label totalTimeLabel;
		private System.Windows.Forms.Label currentTimeLabel;
		private System.Windows.Forms.Button playPauseButton;
		private System.Windows.Forms.Button stopButton;
		private System.Windows.Forms.Panel volumeControlPanel;
		private DevComponents.DotNetBar.ButtonX muteButton;
		private System.Windows.Forms.TrackBar volumeTrackBar;
		private System.Windows.Forms.Label volumenum;
		private DevComponents.DotNetBar.ButtonX zoomInButton;
		private DevComponents.DotNetBar.ButtonX zoomOutButton;
		private DevComponents.DotNetBar.ButtonX fitToWindowButton;
		private System.Windows.Forms.ProgressBar rightChannelProgressBar;
		private System.Windows.Forms.Panel panel1;
		private DevComponents.DotNetBar.ButtonX vieweMax;
		private System.Windows.Forms.ProgressBar leftChannelProgressBar;
		private LibVLCSharp.WinForms.VideoView videoView1;
		private System.Windows.Forms.TextBox temp2;
		private DevComponents.DotNetBar.ButtonX buttonX1;
	}
}
#endregion 